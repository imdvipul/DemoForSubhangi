import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageInputField: UITextField!
    
    // Demo messages
    private var messages = ["Hello!", "How are you?", "I'm good, thanks!", "What about you?", "I'm doing great!","Hello!", "How are you?", "I'm good, thanks!", "What about you?", "I'm doing great!","Hello!", "How are you?", "I'm good, thanks!", "What about you?", "I'm doing great!"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Chat"
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "chatCell")
        
        messageInputField.delegate = self
        
        // Scroll to the last message when the view loads
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: self.messages.count - 1, section: 0)
            self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
    }
    
    // Send message action
    @IBAction func sendMessage(_ sender: UIButton) {
        guard let message = messageInputField.text, !message.isEmpty else {
            return
        }
        
        messages.append(message)
        messageInputField.text = ""
        
        tableView.reloadData()
        let indexPath = IndexPath(row: messages.count - 1, section: 0)
        tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
    }
    
    // MARK: - UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "chatCell", for: indexPath)
        cell.textLabel?.text = messages[indexPath.row]
        cell.textLabel?.numberOfLines = 0
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let message = messages[indexPath.row]
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.width - 32, height: CGFloat.greatestFiniteMagnitude))
        label.numberOfLines = 0
        label.text = message
        label.sizeToFit()
        return label.frame.height + 20
    }
}





////
////  ViewController.swift
////  demo111111
////
////  Created by Kijang Technology on 17/05/24.
////
//
//import UIKit
//
//enum btnName {
//    case linkbtn
//    case viewbtn
//    case commentsbtn
//}
//
//
//class ViewController: UIViewController {
//    
//    @IBOutlet weak var txtMsg: UITextField!
//    
//    override func viewDidLoad() {
//        fetchMessages(isFromTimer: true)
//    }
//    
//    func fetchMessages(isFromTimer: Bool) {
//    
//        if newMessages |= self.MsgList {
//            self.view.endEditing(false)
//            self.MsgList = newlessages
//            self.tblView.reloadData()
//            self.scrollToBottom()
//            if self.txtMsg.isEditing {
//                self.txtMsg.becomeFirstResponder()
//            }
//        }
//    }
//}
//
//
//class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
//    
//    @IBOutlet weak var tableview: UITableView!
//    
//    override func viewDidLoad() {
//        
//    }
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        var cell = UITableViewCell()
//        
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        
//        if var collVC = self.storyboard?.instantiateViewController(withIdentifier: "CollViewController") as CollViewController {
//            
//            //Ahiya thi index pass kari
//            collVC.selectedIndex = indexPath.row
//        }
//    }
//}
//
//class CollViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
//    
//    // Aa new variable banavyo
//    var selectedIndex = 0
//    @IBOutlet weak var collView: UICollectionView!
//    
//    override func viewDidLoad() {
//        self.collView.delegate = self
//        self.collView.dataSource = self
//        
//        // Aa line lakhvi padse
//        self.collView.scrollToItem(at: IndexPath(row: selectedIndex, section: 0), at: .centeredHorizontally, animated: false)
//    }
//}
//
//func navigateToNextImage () {
//    if self.selectedIndex < galleryListModel0bj.count {
//        self.selectedIndex =  self.selectedIndex + 1
//        self.collView.scrollToItem(at: IndexPath(item: self.selectedIndex, section: 0), at: .centeredHorizontally, animated: true)
//    }
//}
//
//
//
//
//
////class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, UICollection {
////    
////    
////    //MARK: - Tableview delegate and datasource methods
////    
////    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
////        return 10
////    }
////    
////    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
////        var cell = tableviewCell()
////        
////        let inputFormat = "yyyy-4-dd HH:mn: Ss°
////        let outputForsat = "dd-HM-yyyy"
////        let dateFormatter = DateFormatter()
////        dateFormatter.dateFormat = inputFormat
////        
////        cell.img.layer.cornerRadius = cell.img.frame-width / 2
////        cell.lblTrees.text = self.myPlotData?.data?.plantationDetails?.treeDetails?[indexPath.row].treeName
////        cell.no0fTrees.text = self.myPlotData?.data?.plantationDetails?.treeDetails?[indexPath.row].saplingAge
////        cell.ing.kf.setImage(with: URL(string: self.myPlotData?.data?.plantationDetails?.treeDetails?[indexPath.row]
////        let dateStringTrees = self.myPlotData?.data?.plantationDetails?.treeDetails?[indexPath.row].createAt
////        if let date = dateFormatter.date(from: dateStringTrees!) {
////            dateFormatter.dateFormat = outputFormat
////            let formattedDate = dateFormatter.string (from: date)
////            cell.lblDate.text = formattedDate
////        }
////                                       
////        if indexPath.row = 0 {
////            cell.lblTitle.text = "Tree"
////            cell.lbINoTrees.text = "No of trees"
////            cell.lblPlanted. text = "Planted"
////        }
////    }
////    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
////            let temp: UITabBarController = member_homeStoryboard.instantiateViewController(withIdentifiert:"")
////            temp.selectedIndex = 0
////            self.navigationController?.pushViewController(temp,animated: false)
////            NotificationCenter.default.post(name: .intValueNotification, object: nil, userInfo: ["value": solf.notification[indexPath.row].action_id])
////        }
////}
////                                       
////override func viewDidLoad() {
////       super.viewDidLoad()
////
////       // Add observer for the notification
////       NotificationCenter.default.addObserver(self, selector: #selector(handleIntValueNotification(_:)), name: .intValueNotification, object: nil)
////   }
////
////class tableviewCell : UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource {
////    
////    var vc = UIViewController()
////    
////    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
////        return 10
////    }
////    
////    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
////        var cell = collectionCell()
////        cell.vc = vc
////    }
////     
////}
////
////class collectionCell: UICollectionViewCell {
////    
////    var vc = UIViewController()
////    
////    @IBAction func btnAction(sender: UIButton) {
////        
////        vc.navigationController?.pushViewController(<#T##viewController: UIViewController##UIViewController#>, animated: <#T##Bool#>)
////    }
////    
////    if indexPath.section = 0 {
////        cell.lblTitle.text = "Tree"
////        cell.lbINoTrees.text = "No of trees"
////        cell.lblPlanted.text = "Planted"
////    }
////    else {
////        cell.lblTitle.text = ""
////        cell.lbINoTrees.text = ""
////        cell.lblPlanted.text = ""
////        
////        cell.lblTitle.hide = true
////        cell.lbINoTrees.hide = true
////        cell.lblPlanted.hide = true
////    }
////    
////}
////
////
////
////class HomeViewController: UIViewController {
////
////   override func viewDidLoad() {
////       super.viewDidLoad()
////
////       NotificationCenter.default.addObserver(self, selector: #selector(handleIntValueNotification(_:)), name: .intValueNotification, object: nil)
////   }
////
////   @objc func handleIntValueNotification(_ notification: Notification) {
////       if let userInfo = notification.userInfo, let value = userInfo["value"] as? Int {
////           print("Received int value: \(value)")
////       }
////   }
////
////   deinit {
////       NotificationCenter.default.removeObserver(self, name: .intValueNotification, object: nil)
////   }
////}
////
